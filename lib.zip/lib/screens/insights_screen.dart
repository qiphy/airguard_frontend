import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../widgets/probability_bars.dart';

class InsightsScreen extends StatefulWidget {
  const InsightsScreen({super.key});

  @override
  State<InsightsScreen> createState() => _InsightsScreenState();
}

class _InsightsScreenState extends State<InsightsScreen> {
  final api = ApiService(const String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://localhost:8082',
  ));

  late Future<Map<String, dynamic>> future;

  @override
  void initState() {
    super.initState();
    future = api.fetchPrediction();
  }

  void _reload() {
    setState(() => future = api.fetchPrediction());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("AI Insights"),
        actions: [
          IconButton(onPressed: _reload, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          }

          final data = snapshot.data!;
          final pred = data["prediction"] as Map<String, dynamic>;
          final risk = pred["risk"]?.toString() ?? "UNKNOWN";
          final confidence = ((pred["confidence"] ?? 0) as num).toDouble();
          final probs = (pred["probs"] ?? {}) as Map<String, dynamic>;
          final explanation = data["explanation"]?.toString() ?? "";
          final features = (data["features_used"] ?? {}) as Map<String, dynamic>;

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _riskHeader(context, risk, confidence),
              const SizedBox(height: 16),

              Card(
                elevation: 0,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: ProbabilityBars(probs: probs),
                ),
              ),
              const SizedBox(height: 16),

              Card(
                elevation: 0,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Why this prediction?",
                          style: Theme.of(context).textTheme.titleSmall),
                      const SizedBox(height: 8),
                      Text(explanation.isEmpty
                          ? "No explanation available."
                          : explanation),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),

              Card(
                elevation: 0,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Features used",
                          style: Theme.of(context).textTheme.titleSmall),
                      const SizedBox(height: 12),
                      _kv("AQI", features["aqi"]),
                      _kv("PM2.5 (µg/m³)", features["pm25"]),
                      _kv("PM10", features["pm10"]),
                      _kv("O₃", features["o3"]),
                      _kv("CO", features["co"]),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 16),
              Text(
                "Note: This model is designed to be lightweight and explainable for low-cost deployment.",
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _riskHeader(BuildContext context, String risk, double confidence) {
    final pct = (confidence * 100).clamp(0, 100).toStringAsFixed(0);
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Predicted risk",
                      style: Theme.of(context).textTheme.titleSmall),
                  const SizedBox(height: 8),
                  Text(
                    risk,
                    style: Theme.of(context)
                        .textTheme
                        .headlineMedium
                        ?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 6),
                  Text("Confidence: $pct%"),
                ],
              ),
            ),
            const Icon(Icons.psychology, size: 36),
          ],
        ),
      ),
    );
  }

  Widget _kv(String k, dynamic v) {
    String text;
    if (v == null) {
      text = "—";
    } else if (v is num) {
      text = v.toStringAsFixed(2);
    } else {
      text = v.toString();
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(k),
          Text(text, style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
