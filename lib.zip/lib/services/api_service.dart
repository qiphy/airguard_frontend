import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  final String baseUrl;

  ApiService(this.baseUrl);

Future<Map<String, dynamic>> fetchPrediction() async {
  final res = await http.post(
    Uri.parse('$baseUrl/predict'),
    headers: {'Content-Type': 'application/json'},
    body: jsonEncode({}),
  );
  if (res.statusCode != 200) {
    throw Exception('Failed to fetch prediction: ${res.statusCode} ${res.body}');
  }
  return jsonDecode(res.body) as Map<String, dynamic>;
}



Future<Map<String, dynamic>> fetchLatest() async {
  final res = await http.get(Uri.parse('$baseUrl/latest'));
  if (res.statusCode != 200) {
    throw Exception('Failed to fetch latest: ${res.statusCode} ${res.body}');
  }
  return jsonDecode(res.body);
}

Future<Map<String, dynamic>> fetchHistory({int hours = 24}) async {
  final res = await http.get(Uri.parse('$baseUrl/history?hours=$hours'));
  if (res.statusCode != 200) {
    throw Exception('Failed to fetch history: ${res.statusCode} ${res.body}');
  }
  return jsonDecode(res.body) as Map<String, dynamic>;
}

}